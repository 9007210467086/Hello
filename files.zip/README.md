# Ibamba Quotes — Web Application

A full-stack quote management system for Ibamba Accounting Tax and Advisory.

## Features

- **Role-based access**: Staff, Manager, CEO with different permissions
- **Quote builder**: Full assessment tool with all fee calculations
- **Discount approval workflow**:
  - ≤10% discount → Manager approval required
  - >10% discount → CEO approval required
  - CEO can approve all discounts directly
- **Notifications**: In-app + email notifications for approvals
- **Quote history**: All quotes saved automatically with audit trail
- **Ibamba branding**: Gold (#B8973C) and dark colour scheme

---

## Deployment — Step by Step

### 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project (choose a region close to South Africa)
3. Go to **SQL Editor** and paste the entire contents of `supabase-schema.sql` — run it
4. Note your **Project URL** and **anon key** from Settings → API

### 2. Deploy to Vercel

1. Create a free account at [vercel.com](https://vercel.com)
2. Push this folder to a GitHub repository
3. In Vercel, click "New Project" and import your GitHub repo
4. Add the following **Environment Variables** in Vercel:

```
NEXT_PUBLIC_SUPABASE_URL     = https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = your_anon_key
SUPABASE_SERVICE_ROLE_KEY    = your_service_role_key  (from Supabase Settings → API)
NEXT_PUBLIC_APP_URL          = https://your-app.vercel.app
RESEND_API_KEY               = re_xxx  (optional — for email notifications, sign up free at resend.com)
EMAIL_FROM                   = quotes@ibamba.co.za
CEO_EMAIL                    = nomahlubi@ibamba.co.za
MANAGER_EMAIL                = manager@ibamba.co.za
```

5. Click Deploy — it will be live in ~2 minutes

### 3. Create your first user (CEO)

After deploying, you need to create the initial CEO account via Supabase:

1. Go to Supabase → Authentication → Users → "Invite user"
2. Enter your email and a temporary password
3. Then run this SQL in the Supabase SQL Editor to set the role:
```sql
UPDATE public.profiles 
SET role = 'ceo', full_name = 'Nomahlubi Mayisa'
WHERE email = 'your@email.com';
```
4. Sign in to the app and create other users from the User Management page

---

## User Roles & Discount Approval

| Role    | Can quote | Approve ≤10% | Approve >10% |
|---------|-----------|--------------|--------------|
| Staff   | ✓         | ✗            | ✗            |
| Manager | ✓         | ✓            | ✗            |
| CEO     | ✓         | ✓            | ✓            |

When a staff member saves a quote with a discount:
- The quote enters **pending** status
- Manager/CEO receives an **in-app notification** + **email** (if Resend is configured)
- The quote cannot be marked as sent until approved
- Approved/rejected notifications are sent back to the staff member

---

## Local Development

```bash
npm install
cp .env.example .env.local
# Fill in your Supabase credentials in .env.local
npm run dev
# Open http://localhost:3000
```

---

## Project Structure

```
src/
  app/
    api/
      quotes/save/route.ts   ← Save quote + trigger approval workflow
      users/create/route.ts  ← Create users (CEO only)
    dashboard/page.tsx        ← Main dashboard
    quotes/
      page.tsx                ← Quote list
      new/page.tsx            ← New quote (wraps QuoteBuilder)
      [id]/page.tsx           ← Quote detail + approval actions
    approvals/page.tsx        ← Pending approvals for manager/CEO
    users/page.tsx            ← User management (CEO only)
    login/page.tsx            ← Login page
  components/
    QuoteBuilder.tsx          ← Full assessment tool
    Sidebar.tsx               ← Navigation + notification badge
    AuthProvider.tsx          ← Auth context
  lib/
    supabase.ts               ← Supabase client + types
    fees.ts                   ← Fee calculation engine (shared)
supabase-schema.sql           ← Database schema — run once in Supabase
```
