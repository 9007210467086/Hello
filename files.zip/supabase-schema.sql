-- ============================================================
-- IBAMBA QUOTES — SUPABASE SCHEMA
-- Run this entire script in the Supabase SQL editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── Users / profiles ─────────────────────────────────────────
-- Extends Supabase auth.users
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  full_name   text not null,
  role        text not null check (role in ('staff', 'manager', 'ceo')),
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Everyone can read all profiles (needed for approval names)
create policy "Profiles are readable by authenticated users"
  on public.profiles for select
  using (auth.role() = 'authenticated');

-- Users can update their own profile
create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Only CEO can insert profiles (user management)
create policy "CEO can manage profiles"
  on public.profiles for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'ceo'
    )
  );

-- ── Quotes ────────────────────────────────────────────────────
create table public.quotes (
  id              uuid primary key default uuid_generate_v4(),
  proposal_number text not null unique,
  created_by      uuid not null references public.profiles(id),
  client_name     text not null,
  contact_name    text,
  entity_type     text not null,
  reg_number      text,
  tax_number      text,
  vat_number      text,
  year_end        text,
  incorporation_date date,

  -- Quote data (full JSON snapshot)
  line_items      jsonb not null default '[]',
  subtotal        numeric(12,2) not null default 0,
  discount_pct    numeric(5,2) not null default 0,
  discount_amount numeric(12,2) not null default 0,
  total           numeric(12,2) not null default 0,
  monthly_retainer numeric(12,2),
  annual_retainer  numeric(12,2),

  -- Full assessment data snapshot (for regeneration)
  assessment_data jsonb not null default '{}',

  -- Status workflow
  status          text not null default 'draft'
                  check (status in ('draft','pending_manager','pending_ceo','approved','rejected','sent')),

  -- Discount approval
  discount_requested_by uuid references public.profiles(id),
  discount_requested_at timestamptz,
  discount_approved_by  uuid references public.profiles(id),
  discount_approved_at  timestamptz,
  discount_rejected_by  uuid references public.profiles(id),
  discount_rejected_at  timestamptz,
  discount_rejection_note text,
  discount_approval_note  text,

  -- Email
  email_subject   text,
  email_body      text,
  email_sent_at   timestamptz,

  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.quotes enable row level security;

-- All authenticated users can read all quotes
create policy "Authenticated users can read quotes"
  on public.quotes for select
  using (auth.role() = 'authenticated');

-- Staff/manager/ceo can insert
create policy "Authenticated users can insert quotes"
  on public.quotes for insert
  with check (auth.role() = 'authenticated');

-- Staff can update their own quotes (while draft)
create policy "Staff can update own draft quotes"
  on public.quotes for update
  using (
    auth.uid() = created_by
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role in ('manager','ceo')
    )
  );

-- ── Approval notifications ────────────────────────────────────
create table public.notifications (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  quote_id    uuid not null references public.quotes(id) on delete cascade,
  type        text not null check (type in ('approval_requested','approved','rejected','quote_sent')),
  message     text not null,
  is_read     boolean not null default false,
  created_at  timestamptz not null default now()
);

alter table public.notifications enable row level security;

create policy "Users can read their own notifications"
  on public.notifications for select
  using (auth.uid() = user_id);

create policy "Authenticated users can insert notifications"
  on public.notifications for insert
  with check (auth.role() = 'authenticated');

create policy "Users can update their own notifications"
  on public.notifications for update
  using (auth.uid() = user_id);

-- ── Auto-update updated_at ────────────────────────────────────
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger quotes_updated_at
  before update on public.quotes
  for each row execute function update_updated_at();

create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function update_updated_at();

-- ── Auto-create profile on signup ─────────────────────────────
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    coalesce(new.raw_user_meta_data->>'role', 'staff')
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ── Proposal number sequence ──────────────────────────────────
create sequence if not exists proposal_seq start 101;

create or replace function next_proposal_number()
returns text as $$
begin
  return 'IBA' || lpad(nextval('proposal_seq')::text, 3, '0');
end;
$$ language plpgsql;
